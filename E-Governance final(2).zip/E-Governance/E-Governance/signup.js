const email = document.getElementById('email')
const password = document.getElementById('password')
const name = document.getElementById('name')
const phone = document.getElementById('phone')

const errorElement =document.getElementById('error')

form.addEventListener('submit', (e) =>{
    let messages = []
    if (name.value === '' || name.value == null){
        messages.push('Name is Required')
    }
    if (phone.value === '' || phone.value == null){
        messages.push('Phone is Required')
    }
    
    
    if (email.value === '' || email.value == null){
        messages.push('Email is Required')
    }
    
    
    
    if (password.value.length <= 8){
        messages.push('Password must be longer than 8 characters')

    }
    if (password.value.length >= 20){
        messages.push('Password must be longer than 20 characters')

    }
    if (password.value === '' || password.value == null){
        messages.push('Password is Required')
    }

    if (messages.length > 0){
        e.preventDefault()
        errorElement.innerText = messages.join(', ')

    }
    
    
    
})