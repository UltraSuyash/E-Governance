const email = document.getElementById('email')
const password = document.getElementById('password')
const name = document.getElementById('name')
const age = document.getElementById('age')
const phone = document.getElementById('phone')
const adhar = document.getElementById('adhar')
const address = document.getElementById('address')
const gender = document.getElementById('gender')
const errorElement =document.getElementById('error')

form.addEventListener('submit', (e) =>{
    let messages = []
    if (name.value === '' || name.value == null){
        messages.push('Name is Required')
    }
    if (phone.value === '' || phone.value == null){
        messages.push('Phone is Required')
    }
    if (adhar.value === '' || adhar.value == null){
        messages.push('Adhar No. is Required')
    }
    if (email.value === '' || email.value == null){
        messages.push('Email is Required')
    }
    if (age.value === '' || age.value == null){
        messages.push('Age is Required')
    }
    if (address.value === '' || address.value == null){
        messages.push('Address is Required')
    }
    if (gender.value === '' || gender.value == null){
        messages.push('Gender is Required')
    }
    if (password.value.length <= 8){
        messages.push('Password must be longer than 8 characters')

    }
    if (password.value.length >= 20){
        messages.push('Password must be longer than 20 characters')

    }
    if (password.value === '' || password.value == null){
        messages.push('Password is Required')
    }

    if (messages.length > 0){
        e.preventDefault()
        errorElement.innerText = messages.join(', ')

    }
    
    
    
})