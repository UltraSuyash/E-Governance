const name = document.getElementById('name')
const panchayat = document.getElementById('panchayat')
const distric = document.getElementById('distric')
const state = document.getElementById('state')
const description = document.getElementById('description')
const errorElement =document.getElementById('error')

form.addEventListener('submit', (e) =>{
    let messages = []
    if (name.value === '' || name.value == null){
        messages.push('Phone is Required')
    }
    if (panchayat.value === '' || panchayat.value == null){
        messages.push('Panchayat. is Required')
    }
    if (distric.value === '' || distric.value == null){
        messages.push('District is Required')
    }
    if (state.value === '' || state.value == null){
        messages.push('State is Required')
    }
    if (crime description.value === '' || crime description.value == null){
        messages.push('Crime Description is Required')
    }
    

    if (messages.length > 0){
        e.preventDefault()
        errorElement.innerText = messages.join(', ')

    }
    
    
    
})